# 魔改

#!/usr/bin/env python
# coding: utf-8

# ### 0.1.2 Install libraries, Jupyter Notebook

# ```
# conda env create -f environment.yml
# conda activate algonauts
# ```

# ### 0.1.3 Import the libraries


import os
import numpy as np
from pathlib import Path
from PIL import Image
from tqdm import tqdm
import matplotlib
from matplotlib import pyplot as plt
from nilearn import datasets
from nilearn import plotting
import torch
from torch.utils.data import DataLoader, Dataset
from torchvision.models.feature_extraction import create_feature_extractor, get_graph_node_names
from torchvision import transforms
from sklearn.decomposition import IncrementalPCA
from sklearn.linear_model import LinearRegression
from scipy.stats import pearsonr as corr

#from SFCNet import *

import torch
from torch import nn, optim
from torch.utils.data import DataLoader

from optparse import OptionParser
import numpy as np
import visdom
import os
import sys
import math


# ## 1.1 Define paths
# 
# Let's define some paths that we will need for loading and storing data.

class argObj:
    def __init__(self, data_dir, parent_submission_dir, subj):
        self.subj = format(subj, '02')
        self.data_dir = os.path.join(data_dir, 'subj' + self.subj)
        self.parent_submission_dir = parent_submission_dir
        self.subject_submission_dir = os.path.join(self.parent_submission_dir,
                                                   'subj' + self.subj)

        # Create the submission directory if not existing
        if not os.path.isdir(self.subject_submission_dir):
            os.makedirs(self.subject_submission_dir)

class SevTDataset(torch.utils.data.Dataset):
    def __init__(self, imgs_paths, idxs, vs, transform):  # (图像文件夹，txt文件，fMRI数据，128)
        #self.data = data
        self.transform = transform  # 默认为None
        self.imgs_paths = np.array(imgs_paths)[idxs]  # 图像文件夹
        self.voxels = vs[idxs]   # fMRI数据
        self.transform = transform
        #self.idxs = idxs

    def __getitem__(self, idx):

        img_path = self.imgs_paths[idx]
        img = Image.open(img_path).convert('RGB')
        # Preprocess the image and send it to the chosen device ('cpu' or 'cuda')
        if self.transform:
            img = self.transform(img).to(device)
        v = self.voxels[idx]  # 挑选与该图像刺激相对应的fMRI数据
        #print ()
        return img, v   # 刺激图像，类别标签，fMRI信号

    def __len__(self):
        return len(self.imgs_paths)   # 训练集或测试集样本量

# We will now create a DataLoader class that allow us to iterate over batches of images. We use batches because loading and processing all images at once uses too much memory.

# Let's delete the original fMRI training split to free up RAM.

# ## 2.2 Extract and downsample image features from AlexNet
# 
# In this step we will extract image features from a pretrained AlexNet, and downsample them to 100 PCA components to speed up computations in the the next encoding step (mapping of AlexNet feature onto fMRI features).

# ### 2.2.1 Load the pretrained AlexNet
# 
# We will load the pretrained AlexNet from the [PyTorch Hub][pytorch_hub] and set it to evaluation mode since we will not be training this network.
#   构建网络，显示网络结构
class SFCLinear(nn.Module):
    def __init__(self, in_features, out_features, c,  h,w, c1):  # (16*16*128,体素数量,128,16,16,128)
        super(SFCLinear, self).__init__()

        self.w = nn.Parameter(torch.randn(in_features, out_features))#randn标准正态分布
        self.b = nn.Parameter(torch.randn(out_features))

        self.w.data.uniform_(-0.1, 0.1)  # 用从均匀分布中抽样得到的值进行填充
        self.b.data.uniform_(-0.1, 0.1)  # 用从均匀分布中抽样得到的值进行填充

    def forward(self, x):
        x = x.mm(self.w ** 2)  # 注意这里使用的是权值的平方
        return x + self.b


class ConvBlock(nn.Module):
    def __init__(self, inchannel, outchannel, kernel, stride):  # (128,128,3,2)
        super(ConvBlock, self).__init__()
        self.layer = nn.Sequential(
            nn.Conv2d(inchannel, outchannel, kernel_size=kernel, stride=stride, padding=(kernel - 1) // 2),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        out = self.layer(x)
        return out


class SFCNet(nn.Module):
    def __init__(self, size, base_channel=64, block_num=3, kernel=3, stride=2, num=1294, selected_channel=64):  # (128,128,2,3,2,体素数量,128)
        super(SFCNet, self).__init__()

        self.inchannel = base_channel  # 128
        self.conv1 = nn.Conv2d(3, base_channel, kernel_size=3, stride=2, padding=1)
        self.relu = nn.ReLU(inplace=True)
        self.layer = self.make_layer(ConvBlock, base_channel, block_num, kernel, stride)  # (ConvBlock,128,2,3,2)

        h = size // (stride ** (block_num + 1))  # 128//2**3 = 16
        w = size // (stride ** (block_num + 1))  # 128//2**3 = 16
        out_dims = h * w * self.inchannel  # 16*16*128
        print(h, w, self.inchannel, out_dims, num)

        self.fc = SFCLinear(out_dims, num, base_channel, h, w, selected_channel)  # (16*16*128,体素数量,128,16,16,128)

    def make_layer(self, block, channels, num_blocks, kernel, stride):  # (ConvBlock,128,2,3,2)
        layers = []
        for i in range(num_blocks):  # 2
            if i == (num_blocks - 1):
                layers.append(block(self.inchannel, channels, kernel, stride))
            else:
                layers.append(block(self.inchannel, channels, kernel, stride))  # (128,128,3,2)
            self.inchannel = channels  # 128
            channels = channels * 1

        return nn.Sequential(*layers)

    def forward(self, x):
        x = self.relu(self.conv1(x))  # (N,128,64,64)
        x = self.layer(x)  # (N,128,16,16)
        x = x.view(x.shape[0], -1)  # (N,128*16*16)
        x = self.fc(x)  # (N,体素数量)

        return x

    def features(self, x):  # 提取特征
        x = self.relu(self.conv1(x))
        x = self.layer(x)

        return x


def cor_v(x1, x2):
    x1_mean, x1_var = torch.mean(x1, 0), torch.var(x1, 0)  # 每一列(每一个体素)求出一个均值和一个方差，最后shape为(N,)
    x2_mean, x2_var = torch.mean(x2, 0), torch.var(x2, 0)  # 每一列(每一个体素)求出一个均值和一个方差，最后shape为(N,)
    corVector = torch.mean((x1-x1_mean)*(x2-x2_mean), 0)
    corVector = corVector/(1e-6+torch.sqrt(x1_var*x2_var))  # 这个是计算的皮尔逊相关系数
    return corVector   # 皮尔逊相关系数反映的是两组数列同时高于均值或低于均值的情况，而不是同时变大变小的情况


def loss_w(x1, x2):
    corVector = cor_v(x1, x2)
#   loss1 = torch.mean(corVector)
    loss2 = torch.mean(corVector**3)  # 返回所有元素的平均值？？、？
    return -loss2


def mse_v(x1, x2):
    mseVector = torch.mean((x1-x2)**2, 0)  # 最后shape为(N,)
    return mseVector


def topk(x, k):  # (形状为1行N列，300)
    corTopkv, corTopki = torch.topk(x, k)  # 取x中前k大的值及其索引值
    corTopk = torch.mean(corTopkv)
    return corTopk, corTopki  # 返回均值，索引值


def ptopk(x, ix):
    numsv = ix.shape[0]
    tmp = 0
    for i in range(numsv):
        tmp = tmp + x[ix[i]]
    tmp = tmp/int(numsv)
    return tmp


## modify!!!!!!!
def eval_model_challenge(net, dataset, bs):  # （稀疏全连接网络，训练数据，70，300）
    loader = torch.utils.data.DataLoader(dataset, batch_size=bs, shuffle=False, num_workers=0, drop_last=False)

    cor = 0.0
    mse = 0.0
    count = 0

    net.eval()

    all_voxel_vector = []

    for i, data in enumerate(loader):
        imgs, voxels = data  # 图像，标签，体素信号
        imgs = imgs.float().cuda()
        voxels = voxels.float().cuda()


        pred = net(imgs)  # 预测得到的大脑信号
        cor_v_ = cor_v(pred, voxels)  # 计算得到皮尔逊相关系数，shape为(N,)
        mse_v_ = mse_v(pred, voxels)  # 计算得到均方误差，shape为(N,)

        cor = cor + cor_v_.mean().item()  # 这是一个数
        mse = mse + mse_v_.mean().item()  # 这是一个数

        all_voxel_vector.append(cor_v_.cpu().detach().numpy())

        count = count + 1

        # pred = torch.tensor(pred)
        # pred = pred.cpu().numpy()


    cor = cor/count  # 这是所有体素取平均
    mse = mse/count  # 这是所有体素取平均

    all_voxel_vector = np.reshape(np.array(all_voxel_vector), (-1,))
    median = np.median(all_voxel_vector)

    return cor, mse, median




def eval_model(net, dataset, bs, k, index_cor=None, index_mse=None):  # （稀疏全连接网络，训练数据，70，300）
    loader = torch.utils.data.DataLoader(dataset, batch_size=bs, shuffle=False, num_workers=0, drop_last=False)

    cor = 0.0
    mse = 0.0
    corVector = 0
    mseVector = 0
    count = 0

    net.eval()
    pred_eval = np.zeros((1, length_voxel))
    pred_eval = torch.tensor(pred_eval)
    pred_eval = pred_eval.cpu().numpy()
    for i, data in enumerate(loader):
        imgs, voxels = data  # 图像，标签，体素信号
        imgs = imgs.float().cuda()
        voxels = voxels.float().cuda()


        pred = net(imgs)  # 预测得到的大脑信号
        cor_v_ = cor_v(pred, voxels)  # 计算得到皮尔逊相关系数，shape为(N,)
        mse_v_ = mse_v(pred, voxels)  # 计算得到均方误差，shape为(N,)

        cor = cor + cor_v_.mean().item()  # 这是一个数
        mse = mse + mse_v_.mean().item()  # 这是一个数

        corVector = corVector + cor_v_.data  # shape为(N,)
        mseVector = mseVector + mse_v_.data  # shape为(N,)

        count = count + 1


        pred = torch.tensor(pred)
        pred = pred.cpu().numpy()
        pred_eval = np.append(pred_eval, pred, axis = 0)


    cor = cor/count  # 这是所有体素取平均
    mse = mse/count  # 这是所有体素取平均
    corVector = corVector/count  # 这是每个体素自己取平均，shape为(N,)
    mseVector = mseVector/count  # 这是每个体素自己取平均，shape为(N,)

    if index_cor is not None:  # 默认为None
        cor_topk = ptopk(corVector, index_cor)
        mse_topk = ptopk(mseVector, index_cor)
    else:
        cor_topk, index_cor = topk(corVector, k)   # 均值，取前300个皮尔逊相关系数最大的体素的索引值(值越大越好)
        mse_topk, index_mse = topk(-mseVector, k)  # 均值，取前300个均方误差最小的体素的索引值
        mse_topk = -1*mse_topk  # (值越小越好)

    corVector = corVector.cpu().numpy()
    mseVector = mseVector.cpu().numpy()

    return corVector, cor, cor_topk, index_cor, mseVector, mse, mse_topk, index_mse, pred_eval  # 返回每个体素自己取平均，所有体素取平均，前300个体素取均值，前300个体素的索引值


def predict(net, dataset, bs, area):  # （稀疏全连接网络，训练数据，70，300）
    loader = torch.utils.data.DataLoader(dataset, batch_size=bs, shuffle=False, num_workers=0, drop_last=False)

    cor = 0.0
    mse = 0.0
    corVector = 0
    mseVector = 0
    count = 0

    #net.predict()
    net.load_state_dict(torch.load('E:/match/yzy/model_S1/' + area + '_C_best.pth'))
    #net = torch.load('D:/2023/encoding/model_S2/' + area + '_C_best_net.pth')
    #net.predict()
    torch.no_grad()
    prediction = np.zeros((1, length_voxel))
    prediction = torch.tensor(prediction)
    prediction = prediction.cpu().numpy()
    for i, data in enumerate(loader):
        imgs, voxels = data  # 图像，标签，体素信号
        imgs = imgs.float().cuda()
        voxels = voxels.float().cuda()

        out_pred = net(imgs)  # 预测得到的大脑信号
        #out_pred =np.argmax(out_pred,axis=1)
        cor_v_ = cor_v(out_pred, voxels)  # 计算得到皮尔逊相关系数，shape为(N,)
        mse_v_ = mse_v(out_pred, voxels)  # 计算得到均方误差，shape为(N,)

        cor = cor + cor_v_.mean().item()  # 这是一个数
        mse = mse + mse_v_.mean().item()  # 这是一个数

        corVector = corVector + cor_v_.data  # shape为(N,)
        mseVector = mseVector + mse_v_.data  # shape为(N,)

        count = count + 1

        out_pred = torch.tensor(out_pred)
        out_pred = out_pred.cpu().numpy()
        #out_pred = out_pred.detach().numpy()
        prediction = np.append(prediction, out_pred, axis = 0)


    cor = cor/count  # 这是所有体素取平均
    mse = mse/count  # 这是所有体素取平均
    corVector = corVector/count  # 这是每个体素自己取平均，shape为(N,)
    mseVector = mseVector/count  # 这是每个体素自己取平均，shape为(N,)

    corVector = corVector.cpu().numpy()
    mseVector = mseVector.cpu().numpy()

    return corVector, cor, mseVector, mse, prediction  # 返回每个体素自己取平均，所有体素取平均，前300个体素取均值，前300个体素的索引值

def train_net(net,          # 稀疏全连接网络
              epochs,       # 50
              batchsize,    # 64
              lr,           # 0.001
              dataset_trn,  # 训练数据
              dataset_val, # 测试数据
              #dataset_test,
              k,            # 300，挑前300个体素进行相关性分析
              num,          # 体素数量
              viz,          # 可视化的啥玩意
              area,         # v1
              sub,
              save_cp=True,  # True
              gpu=True):     # True

    print('''
    Starting training:
        Epochs: {}
        Batch size: {}
        Learning rate: {}
        Training size: {}
        Validation size: {}
        Checkpoints: {}
        CUDA: {}
        selected voxel num: {}
    '''.format(epochs, batchsize, lr, len(dataset_trn),
               len(dataset_val), str(save_cp), str(gpu), str(k)))

    trace = dict(title=title,
                 xlabel='epoch',
                 ylabel='correlation',
                 legend=['train', 'train_topk', 'test', 'test_topk'],
                 markersymbol='dot')

    trace_mse = dict(title=title_mse,
                     xlabel='epoch',
                     ylabel='mse',
                     legend=['train', 'train_topk', 'test', 'test_topk'],
                     markersymbol='dot')

    loader_trn = torch.utils.data.DataLoader(dataset_trn, batch_size=batchsize, shuffle=True, num_workers=0,
                                             drop_last=True)
    optimizer = optim.Adam(net.parameters(), lr=lr, weight_decay=1e-6)

    best_cor = 0.0
    best_median = 0.0
    for epoch in range(epochs):
        print('Starting epoch {}/{}.'.format(epoch + 1, epochs))

        net.train()
        cor_trn = 0
        count = 0
        for i, data in tqdm(enumerate(loader_trn)):
            imgs,  voxels = data    # 图像，标签，体素信号
            imgs = imgs.float().cuda()
            voxels = voxels.float().cuda()

            pred_v = net(imgs)  # 预测得到的大脑信号
            pred_v = pred_v + 1.0 * torch.randn(pred_v.shape).cuda()  # 加入标准正态分布的高斯白噪声

            loss = loss_w(pred_v, voxels) + 1e-5 * torch.mean(pred_v)  # 添加噪声正则化以防止预测体素V不断变大

            ## cor
            cor_trn = cor_trn + cor_v(pred_v, voxels).mean().item()
            count = count + 1

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        cor_trn = cor_trn / count

        # 一个epoch训练完之后，进行模型测试
        # corVector_trn, cor_trn, cor_topk_trn, index_cor, mseVector, mse_trn, mse_topk_trn, index_mse, lh_fmri_trn_pred = eval_model(net, dataset_trn, 70, k)  # 返回每个体素自己取平均，所有体素取平均，前300个体素取均值，前300个体素的索引值
        # corVector_val, cor_val, corptopk_val, index_cor, mseVector, mse_val, mseptopk_val, index_mse = eval_model(net, dataset_val, 60, k, index_cor, index_mse)  # 返回每个体素自己取平均，所有体素取平均，前300个体素取均值，前300个体素的索引值
        cor_val, mse_val, median_val = eval_model_challenge(net, dataset_val, 128)

        #cor_test, mse_test, median_test = eval_model_challenge(net, dataset_test, 159)

        # corVector_val, cor_val, corptopk_val, index_cor, mseVector, mse_val, mseptopk_val, index_mse, lh_fmri_val_pred = eval_model(
        #     net, dataset_test, 123, k)

        print('\tloss:%.3f' % (loss.cpu().item()))  # 一个epoch结束之后的loss
        print('\ttrain cor:%.3f, val cor:%.3f' % (cor_trn, cor_val))  # 训练集所有体素的平均相关系数，测试集所有体素的平均相关系数
        print('\tval median:%.3f' % (median_val))
        # print('\ttrain cor:%.3f, val cor:%.3f' % (cor_trn, cor_val))  # 训练集所有体素的平均相关系数，测试集所有体素的平均相关系数
        # print('\ttrain topk:%.3f, val ptopk:%.3f' % (cor_topk_trn, corptopk_val))  # 训练集top300体素的平均相关性值，测试集中训练集的top300体素

        # mse_trn = np.log10(mse_trn)
        # mse_val = np.log10(mse_val)
        # mse_topk_trn = np.log10(mse_topk_trn.item())
        # mseptopk_val = np.log10(mseptopk_val.item())
        #
        # if epoch == 0:
        #     win = viz.line(X=np.array([epoch]), Y=np.column_stack((np.array(cor_trn), np.array(cor_topk_trn.item()),\
        #                                                            np.array(cor_val), np.array(corptopk_val.item()))), opts=trace)
        #     win_mse = viz.line(X=np.array([epoch]), Y=np.column_stack((np.array(mse_trn), np.array(mse_topk_trn),\
        #                                                                np.array(mse_val), np.array(mseptopk_val))), opts=trace_mse)
        #
        #     bar_trn = viz.bar(X=corVector_trn)
        #     bar_val = viz.bar(X=corVector_val)
        #
        # else:
        #     viz.line(X=np.array([epoch]), Y=np.column_stack((np.array(cor_trn), np.array(cor_topk_trn.item()),\
        #                                                      np.array(cor_val), np.array(corptopk_val.item()))), win=win, opts=trace, update='append')
        #
        #     viz.line(X=np.array([epoch]), Y=np.column_stack((np.array(mse_trn), np.array(mse_topk_trn),\
        #                                                      np.array(mse_val), np.array(mseptopk_val))), win=win_mse, opts=trace_mse, update='append')
        #
        #     viz.bar(X=corVector_trn, win=bar_trn)
        #     viz.bar(X=corVector_val, win=bar_val)
        #
        if median_val > best_median:
            best_median = median_val
            torch.save(net.state_dict(),'E:/2023/encoding/model_S' + sub + '/' + area + '_C_best.pth')  # 存储模型参数
            torch.save(net, 'E:/2023/encoding/model_S' + sub + '/' + area + '_C_best_net.pth')  # 存储模型参数
            print('Checkpoint {} saved!'.format(epoch + 1))
            file = 'E:/2023/encoding/results/COR_S' + sub + '/' + area + '_medVector_val.npy'
            np.save(file, median_val)  # 存储视觉区训练集各个体素的相关系数
            file = 'E:/2023/encoding/results/COR_S' + sub + '/' + area + '_corVector_val.npy'
            np.save(file, cor_val)  # 存储视觉区训练集各个体素的相关系数



def get_args():
    parser = OptionParser()  # 构造optionparser的对象
    parser.add_option('-e', '--epochs', dest='epochs', default=25, type='int',
                      help='number of epochs')
    parser.add_option('-b', '--batch-size', dest='batchsize', default=128,
                      type='int', help='batch size')
    parser.add_option('-n', '--num', dest='num', default=math.ceil(num_v/2),
                      type='int', help='voxel number')
    parser.add_option('-l', '--learning-rate', dest='lr', default=1e-3,
                      type='float', help='learning rate')
    parser.add_option('-g', '--gpu', action='store_true', dest='gpu',
                      default=True, help='use cuda')
    parser.add_option('-c', '--load', dest='load',
                      default=False, help='load file model')
    #parser.add_option('--data_dir', type=str, default='E:/match/')
    parser.add_option('--gpu_num', type=str, default='0')
    (options, args) = parser.parse_args()  # 调用解析函数

    return options


# if __init__ == __main__:
if __name__ == '__main__':
    os.environ["CUDA_VISIBLE_DEVICES"]="1"

# ## 0.2 Access the tutorial data 数据路径

    data_dir = 'E:/2023/encoding/data'
    parent_submission_dir = 'E:/2023/encoding/algonauts_2023_challenge_submission'

# ## 0.3 Select CPU or GPU

# 使用服务器上的1号卡（注意，此处是从0号卡开始的）
    device = 'cuda'  # @param ['cpu', 'cuda'] {allow-input: true}
    device = torch.device(device)

# # 1 Load and visualize the Challenge data 选几号被试
    subj = 4 # @param ["1", "2", "3", "4", "5", "6", "7", "8"] {type:"raw", allow-input: true}
    sub_str = str(subj)

    # ## 1.2 Load the fMRI training data
    #
    # Now you will load the fMRI training split data of the selected subject. The fMRI data consists of two `'.npy'` files:
    # * ```lh_training_fmri.npy```: the left hemisphere (LH) fMRI data.
    # * ```rh_training_fmri.npy```: the right hemisphere (RH) fMRI data.
    #
    # Both files are 2-dimensional arrays with training stimulus images as rows and fMRI vertices as columns.
    #
    # For more information on the fMRI responses please open the [`README.txt`][readme] file accompanying the Challenge data (preferably with a text editor, otheriwse the formatting might be off).
    #部分数据路径
    args = argObj(data_dir, parent_submission_dir, subj)
    fmri_dir = os.path.join(args.data_dir, 'training_split', 'training_fmri')
    lh_fmri = np.load(os.path.join(fmri_dir, 'lh_training_fmri.npy'))
    rh_fmri = np.load(os.path.join(fmri_dir, 'rh_training_fmri.npy'))

    print('LH training fMRI data shape:')
    print(lh_fmri.shape)
    print('(Training stimulus images × LH vertices)')

    print('\nRH training fMRI data shape:')
    print(rh_fmri.shape)
    print('(Training stimulus images × RH vertices)')


    # ### 1.5.2 Visualize the fMRI image responses of a chosen ROI on a brain surface map
    #
    # Now we visualize the fMRI training image responses of a chosen ROI on a brain surface map. For this we need to select the 2-dimensional fMRI data array vertices falling withing the selected ROI (in `challenge space`), and map them to the corresponding vertices on the brain surface template (in `fsaverage space`).
    #
    # Note that not all ROIs exist for all subjects and hemispheres.

    # In[ ]:
    train_img_dir = os.path.join(args.data_dir, 'training_split', 'training_images')
    test_img_dir = os.path.join(args.data_dir, 'test_split', 'test_images')

    # Create lists will all training and test image file names, sorted
    train_img_list = os.listdir(train_img_dir)
    train_img_list.sort()
    test_img_list = os.listdir(test_img_dir)
    test_img_list.sort()
    print('Training images: ' + str(len(train_img_list)))
    print('Test images: ' + str(len(test_img_list)))

    # The training and test images are stored in `.png` format. As an example, the first training image of subject 1 is named `train-0001_nsd-00013.png`.
    #
    # The first index (`'train-0001'`) orders the images so to match the stimulus images dimension of the fMRI training split data. This indexing starts from 1.
    #
    # The second index (`'nsd-00013'`) corresponds to the 73,000 NSD image IDs that you can use to map the image back to the [original `.hdf5` NSD image file][NSD_img_hdf5] (which contains all the 73,000 images used in the NSD experiment), and from there to the [COCO dataset][coco] images for metadata). The 73,000 NSD images IDs in the filename start from 0, so that you can directly use them for indexing the `.hdf5` NSD images in Python. Note that the images used in the NSD experiment (and here in the Algonauts 2023 Challenge) are cropped versions of the original COCO images. Therefore, if you wish to use the COCO image metadata you first need to adapt it to the cropped image coordinates. You can find code to perform this operation [here][coco_meta].
    #

    # In[ ]:

    train_img_file = train_img_list[0]
    print('Training image file name: ' + train_img_file)
    print('73k NSD images ID: ' + train_img_file[-9:-4])



    img = 0  # @param
    hemisphere = ['l', 'r']  # @param ['left', 'right'] {allow-input: true}
    print(hemisphere[0])
    print(hemisphere[1])
    # Load the image
    img_dir = os.path.join(train_img_dir, train_img_list[img])
    train_img = Image.open(img_dir).convert('RGB')
    rand_seed = 5  # @param
    np.random.seed(rand_seed)

    # Calculate how many stimulus images correspond to 90% of the training data
    num_train = int(np.round(len(train_img_list) / 100 * 90))
    # Shuffle all training stimulus images
    idxs = np.arange(len(train_img_list))
    np.random.shuffle(idxs)
    # Assign 90% of the shuffled stimulus images to the training partition,
    # and 10% to the test partition
    idxs_train, idxs_val = idxs[:num_train], idxs[num_train:]
    # No need to shuffle or split the test stimulus images
    idxs_test = np.arange(len(test_img_list))

    print('Training stimulus images: ' + format(len(idxs_train)))
    print('\nValidation stimulus images: ' + format(len(idxs_val)))
    print('\nTest stimulus images: ' + format(len(idxs_test)))

    # ### 2.1.2 Create the training, validation and test image partitions DataLoaders
    #
    # We will use the `Dataset` and `DataLoader` classes from PyTorch to create our training, validation and test image partitions. You can read more about these type of classes and how to use them [here][data_tutorial_pytorch].
    #
    # Let's first define the preprocessing (transform) that will be applied to the images before feeding them to AlexNet. We will use a [standard preprocessing pipeline][preprocessing] as used in the computer vision literature.
    #

    transform = transforms.Compose([
        transforms.Resize((224, 224)),  # resize the images to 224x24 pixels
        transforms.ToTensor(),  # convert the images to a PyTorch tensor
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])  # normalize the images color channels
    ])

    batch_size = 128  # @param 原始参数300
    # Get the paths of all image files
    train_imgs_paths = sorted(list(Path(train_img_dir).iterdir()))
    test_imgs_paths = sorted(list(Path(test_img_dir).iterdir()))

    #rois = ["V1v", "V1d", "V2v", "V2d", "V3v", "V3d", "hV4", "EBA", "FBA-1", "FBA-2", "mTL-bodies", "OFA", "FFA-1", "FFA-2", "mTL-faces", "aTL-faces", "OPA", "PPA", "RSC", "OWFA", "VWFA-1", "VWFA-2", "mfs-words", "mTL-words", "early", "midventral", "midlateral", "midparietal", "ventral", "lateral", "parietal"]
    #rois = ["V1v", "V1d", "V2v", "V2d", "V3v", "V3d", "hV4"]
    rois = ["midventral", "midlateral", "midparietal", "ventral", "lateral", "parietal"]


    for i in range(len(rois)):
        roi = rois[i]

        print(roi)

        # # Plot the image

        # Define the ROI class based on the selected ROI
        if roi in ["V1v", "V1d", "V2v", "V2d", "V3v", "V3d", "hV4"]:
            roi_class = 'prf-visualrois'
        elif roi in ["EBA", "FBA-1", "FBA-2", "mTL-bodies"]:
            roi_class = 'floc-bodies'
        elif roi in ["OFA", "FFA-1", "FFA-2", "mTL-faces", "aTL-faces"]:
            roi_class = 'floc-faces'
        elif roi in ["OPA", "PPA", "RSC"]:
            roi_class = 'floc-places'
        elif roi in ["OWFA", "VWFA-1", "VWFA-2", "mfs-words", "mTL-words"]:
            roi_class = 'floc-words'
        elif roi in ["early", "midventral", "midlateral", "midparietal", "ventral", "lateral", "parietal"]:
            roi_class = 'streams'

        # Load the ROI brain surface maps
        args = argObj(data_dir, parent_submission_dir, subj)
        challenge_roi_class_dir = os.path.join(args.data_dir, 'roi_masks',
                                               hemisphere[0] + 'h.' + roi_class + '_challenge_space.npy')
        fsaverage_roi_class_dir = os.path.join(args.data_dir, 'roi_masks',
                                               hemisphere[0] + 'h.' + roi_class + '_fsaverage_space.npy')
        roi_map_dir = os.path.join(args.data_dir, 'roi_masks',
                                   'mapping_' + roi_class + '.npy')
        challenge_roi_class = np.load(challenge_roi_class_dir)
        fsaverage_roi_class = np.load(fsaverage_roi_class_dir)
        roi_map = np.load(roi_map_dir, allow_pickle=True).item()

        challenge_roi_class_dir_r = os.path.join(args.data_dir, 'roi_masks',
                                                 hemisphere[1] + 'h.' + roi_class + '_challenge_space.npy')
        fsaverage_roi_class_dir_r = os.path.join(args.data_dir, 'roi_masks',
                                                 hemisphere[1] + 'h.' + roi_class + '_fsaverage_space.npy')
        roi_map_dir_r = os.path.join(args.data_dir, 'roi_masks',
                                     'mapping_' + roi_class + '.npy')
        challenge_roi_class_r = np.load(challenge_roi_class_dir_r)
        fsaverage_roi_class_r = np.load(fsaverage_roi_class_dir_r)
        roi_map_r = np.load(roi_map_dir_r, allow_pickle=True).item()

        # Select the vertices corresponding to the ROI of interest
        roi_mapping = list(roi_map.keys())[list(roi_map.values()).index(roi)]
        challenge_roi = np.asarray(challenge_roi_class == roi_mapping, dtype=int)
        fsaverage_roi = np.asarray(fsaverage_roi_class == roi_mapping, dtype=int)

        roi_mapping_r = list(roi_map_r.keys())[list(roi_map_r.values()).index(roi)]
        challenge_roi_r = np.asarray(challenge_roi_class_r == roi_mapping_r, dtype=int)
        fsaverage_roi_r = np.asarray(fsaverage_roi_class_r == roi_mapping_r, dtype=int)

        # Map the fMRI data onto the brain surface map
        fsaverage_response = np.zeros(len(fsaverage_roi))
        if hemisphere == 'left':
            fsaverage_response[np.where(fsaverage_roi)[0]] = \
                lh_fmri[img, np.where(challenge_roi)[0]]
        elif hemisphere == 'right':
            fsaverage_response[np.where(fsaverage_roi)[0]] = \
                rh_fmri[img, np.where(challenge_roi)[0]]

        # Create the interactive brain surface map
        fsaverage = datasets.fetch_surf_fsaverage('fsaverage')

        # ### 2.1.3 Split the fMRI data into training and validation partitions
        #
        # Here we will use the previously defined indices to split the training fMRI data into a training and validation partition.
        m = len(challenge_roi)
        n = len(challenge_roi_r)
        print(challenge_roi[1])
        lh_fmri_roi = np.zeros((len(train_img_list), m))
        rh_fmri_roi = np.zeros((len(train_img_list), n))

        for p in range(len(train_img_list)):
            o = np.array(list(lh_fmri[p, :]))
            f = np.array((list(challenge_roi)))
            lh_fmri_roi[p, :] = o * f
            #print(f.all())

        lh_fmri_roi = np.delete(lh_fmri_roi, np.where(~lh_fmri_roi.any(axis=0))[0], axis=1)
        if f.any()==False:
            roi=rois[i+1]
            print(roi)

            # # Plot the image

            # Define the ROI class based on the selected ROI
            if roi in ["V1v", "V1d", "V2v", "V2d", "V3v", "V3d", "hV4"]:
                roi_class = 'prf-visualrois'
            elif roi in ["EBA", "FBA-1", "FBA-2", "mTL-bodies"]:
                roi_class = 'floc-bodies'
            elif roi in ["OFA", "FFA-1", "FFA-2", "mTL-faces", "aTL-faces"]:
                roi_class = 'floc-faces'
            elif roi in ["OPA", "PPA", "RSC"]:
                roi_class = 'floc-places'
            elif roi in ["OWFA", "VWFA-1", "VWFA-2", "mfs-words", "mTL-words"]:
                roi_class = 'floc-words'
            elif roi in ["early", "midventral", "midlateral", "midparietal", "ventral", "lateral", "parietal"]:
                roi_class = 'streams'

            # Load the ROI brain surface maps
            args = argObj(data_dir, parent_submission_dir, subj)
            challenge_roi_class_dir = os.path.join(args.data_dir, 'roi_masks',
                                                   hemisphere[0] + 'h.' + roi_class + '_challenge_space.npy')
            fsaverage_roi_class_dir = os.path.join(args.data_dir, 'roi_masks',
                                                   hemisphere[0] + 'h.' + roi_class + '_fsaverage_space.npy')
            roi_map_dir = os.path.join(args.data_dir, 'roi_masks',
                                       'mapping_' + roi_class + '.npy')
            challenge_roi_class = np.load(challenge_roi_class_dir)
            fsaverage_roi_class = np.load(fsaverage_roi_class_dir)
            roi_map = np.load(roi_map_dir, allow_pickle=True).item()

            challenge_roi_class_dir_r = os.path.join(args.data_dir, 'roi_masks',
                                                     hemisphere[1] + 'h.' + roi_class + '_challenge_space.npy')
            fsaverage_roi_class_dir_r = os.path.join(args.data_dir, 'roi_masks',
                                                     hemisphere[1] + 'h.' + roi_class + '_fsaverage_space.npy')
            roi_map_dir_r = os.path.join(args.data_dir, 'roi_masks',
                                         'mapping_' + roi_class + '.npy')
            challenge_roi_class_r = np.load(challenge_roi_class_dir_r)
            fsaverage_roi_class_r = np.load(fsaverage_roi_class_dir_r)
            roi_map_r = np.load(roi_map_dir_r, allow_pickle=True).item()

            # Select the vertices corresponding to the ROI of interest
            roi_mapping = list(roi_map.keys())[list(roi_map.values()).index(roi)]
            challenge_roi = np.asarray(challenge_roi_class == roi_mapping, dtype=int)
            fsaverage_roi = np.asarray(fsaverage_roi_class == roi_mapping, dtype=int)

            roi_mapping_r = list(roi_map_r.keys())[list(roi_map_r.values()).index(roi)]
            challenge_roi_r = np.asarray(challenge_roi_class_r == roi_mapping_r, dtype=int)
            fsaverage_roi_r = np.asarray(fsaverage_roi_class_r == roi_mapping_r, dtype=int)

            # Map the fMRI data onto the brain surface map
            fsaverage_response = np.zeros(len(fsaverage_roi))
            if hemisphere == 'left':
                fsaverage_response[np.where(fsaverage_roi)[0]] = \
                    lh_fmri[img, np.where(challenge_roi)[0]]
            elif hemisphere == 'right':
                fsaverage_response[np.where(fsaverage_roi)[0]] = \
                    rh_fmri[img, np.where(challenge_roi)[0]]

            # Create the interactive brain surface map
            fsaverage = datasets.fetch_surf_fsaverage('fsaverage')

            # ### 2.1.3 Split the fMRI data into training and validation partitions
            #
            # Here we will use the previously defined indices to split the training fMRI data into a training and validation partition.
            m = len(challenge_roi)
            n = len(challenge_roi_r)
            print(challenge_roi[1])
            lh_fmri_roi = np.zeros((len(train_img_list), m))
            rh_fmri_roi = np.zeros((len(train_img_list), n))

            for p in range(len(train_img_list)):
                o = np.array(list(lh_fmri[p, :]))
                f = np.array((list(challenge_roi)))
                lh_fmri_roi[p, :] = o * f

            lh_fmri_roi = np.delete(lh_fmri_roi, np.where(~lh_fmri_roi.any(axis=0))[0], axis=1)

        SevTdataset_trn_L = SevTDataset(train_imgs_paths, idxs_train, lh_fmri_roi, transform)
        SevTdataset_val_L = SevTDataset(train_imgs_paths, idxs_val, lh_fmri_roi, transform)
        # SevTdataset_test_L = SevTDataset(test_imgs_paths, idxs_test, lh_fmri_roi, transform)
        lh_fmri_val = lh_fmri_roi[idxs_val]
        # lh_fmri_val = SevTdataset_val_L[voxels()]

        # (length_img, length_voxel) = lh_fmri_roi.shape()
        try:
            length_voxel = len(lh_fmri_roi[0])
        except TypeError:
            length_voxel = False

        size = 224  # 调整的是输入图像的分辨率9
        base_channel = 224
        block_num = 3
        kernel = 5
        selected_channel = 224
        stride = 2
        num_v = len(lh_fmri_roi[0])
        net = SFCNet(size, base_channel, block_num, kernel, stride, num_v, selected_channel)  # (128,128,2,3,2,体素数量,128)
        print(net.parameters)  # 显示参数量大小

        #   可视化
        title = 'cor/ROI=%s/c=%d/sc=%d/bn=%d' % (
        roi, base_channel, selected_channel, block_num)  # cor/ROI=v1/c=128/sc=128/bn=2
        title_mse = 'mse/ROI=%s/c=%d/sc=%d/bn=%d' % (
        roi, base_channel, selected_channel, block_num)  # mse/ROI=v1/c=128/sc=128/bn=2
        viz_name = 'E_' + roi  # E_v1
        viz = visdom.Visdom(env=viz_name)  # 新建名为'E_v1'的环境
        args = get_args()
        if args.load:
            print('hello')
        else:
            if args.gpu:  # 默认为True
                net.cuda()

            try:
                train_net(net,  # 稀疏全连接网络
                          args.epochs,  # 50
                          args.batchsize,  # 64
                          args.lr,  # 1e-3
                          SevTdataset_trn_L,  # 训练数据
                          SevTdataset_val_L,  # 测试数据
                          # SevTdataset_test_L,
                          args.num,  # 300
                          num_v,  # 体素数量
                          viz,  # 一个可视化的啥玩意
                          roi,  # v1
                          sub_str,
                          gpu=args.gpu)  # True

            except KeyboardInterrupt:
                torch.save(net.state_dict(), 'INTERRUPTED.pth')
                print('Saved interrupt')
                try:
                    sys.exit(0)
                except SystemExit:
                    os._exit(0)
