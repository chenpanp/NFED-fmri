import numpy as np
npy_file = r'G:\zwc\第一个点\Results\Gabor\sub01\Left\MED\V3d_medVector_val.npy'
data = np.load(npy_file)
print(data)