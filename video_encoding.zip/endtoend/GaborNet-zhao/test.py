

# import os
# import numpy as np
#
# directory = '/media/amax/DE105765105744252/endtoend/2023Challenge/data_code/algonauts_2023_challenge_data/subj01/voxel_indexs'
# npy_files = [f for f in os.listdir(directory) if f.endswith('.npy')]
#
# # 自定义排序函数，根据文件名中的数字部分进行排序
# def extract_number(filename):
#     return int(filename.split('.')[0])
#
# npy_files_sorted = sorted(npy_files, key=extract_number)
#
#
# brain_index = np.random.randint(len(npy_files_sorted))

# # 获取选定的文件名
# selected_file = npy_files_truncated[brain_index]




# import numpy as np
# import os
#
# directory_1="/media/amax/DE105765105744251/endtoend/2023Challenge/data_code/algonauts_2023_challenge_data/subj01/voxel_indexs_test"
# npy_files = [f for f in os.listdir(directory_1) if f.endswith('.npy')]
# brain_index = np.random.randint(len(npy_files))
# voxels_index=np.load("/media/amax/DE105765105744251/endtoend/2023Challenge/data_code/algonauts_2023_challenge_data/subj01/voxel_indexs/V1.npy")
# voxels_index=voxels_index-1

#
# import numpy as np
# import os
#
# directory = '/media/amax/DE105765105744251/endtoend/2023Challenge/data_code/algonauts_2023_challenge_data/subj01/voxel_indexs'
# npy_files = [f for f in os.listdir(directory) if f.endswith('.npy')]
#
# def extract_number(filename):
#      return int(filename.split('.')[0])
# npy_files_sorted = sorted(npy_files, key=extract_number)
# # 随机选择一个文件
# brain_index= np.random.randint(len(npy_files_sorted))
# chosen_file= npy_files_sorted [brain_index]
# voxels_index = np.load(os.path.join(directory, chosen_file))
# voxels_index=voxels_index-1



# directory = '/media/amax/DE105765105744251/endtoend/2023Challenge/data_code/algonauts_2023_challenge_data/subj01/voxel_indexs'
# npy_files = [f for f in os.listdir(directory) if f.endswith('.npy')]
#
#     # 随机选择一个文件
# brain_index= np.random.randint(len(npy_files))
# chosen_file= npy_files[brain_index]
# voxels_index = np.load(os.path.join(directory, chosen_file))
# voxels_index=voxels_index-1
#
#
#
#
# import os
#
# directory = '/media/amax/DE105765105744251/endtoend/2023Challenge/data_code/algonauts_2023_challenge_data/subj01/voxel_indexs'
# npy_files = [f for f in os.listdir(directory) if f.endswith('.npy')]
#
# # 自定义排序函数，根据文件名中的数字部分进行排序
# def extract_number(filename):
#     return int(filename.split('.')[0])
#
# npy_files_sorted = sorted(npy_files, key=extract_number)
#
# # 输出排序后的文件名
# print(npy_files_sorted)





# import numpy as np
# import os
#
# directory = '/media/amax/DE105765105744251/endtoend/2023Challenge/data_code/algonauts_2023_challenge_data/subj01/voxel_indexs'
# npy_files = [f for f in os.listdir(directory) if f.endswith('.npy')]
#
# # 随机选择一个文件
# brain_index = np.random.randint(len(npy_files))
# chosen_file = npy_files[brain_index]



import numpy as np
import os

# 文件夹路径
# folder_path = '/media/amax/DE105765105744251/endtoend/2023Challenge/data_code/algonauts_2023_challenge_data/subj01/training_split/2222'  # 替换为你的文件夹路径

#
# def load_npy_file(brain_index):
#     # 获取文件夹中所有的 .npy 文件
#     npy_files = [f for f in os.listdir(folder_path) if f.endswith('.npy')]
#
#     # 根据 brain_index 选择对应的文件
#     if 0 <= brain_index < len(npy_files):
#         file_to_load = npy_files[brain_index]
#         file_path = os.path.join(folder_path, file_to_load)
#
#         # 加载 .npy 文件
#         data = np.load(file_path)
#         return data
#     else:
#         raise IndexError("brain_index 超出范围")
# brain_index = 1
#
# data = load_npy_file(brain_index)





    # 继续你的处理流程...

# import numpy as np
# import os
# import random
# a=np.load("/media/amax/DE105765105744251/endtoend/2023Challenge/data_code/algonauts_2023_challenge_data/subj01/training_split/training_fmri/lh_training_fmriv3.npy")
# voxels=np.load("/media/amax/DE105765105744251/endtoend/2023Challenge/data_code/algonauts_2023_challenge_data/subj01/training_split/training_fmri/lh_training_fmri.npy")
#
# brain_index=np.load("/media/amax/DE105765105744251/endtoend/2023Challenge/data_code/algonauts_2023_challenge_data/subj01/voxel_indexs/V3.npy")
# brain_index=brain_index-1
#
# voxels = voxels[:, brain_index]
#
#
#
#
# directory = '/media/amax/DE105765105744251/endtoend/2023Challenge/data_code/algonauts_2023_challenge_data/subj01/voxel_indexs'  # 替换为你的 .npy 文件所在目录
# npy_files = [f for f in os.listdir(directory) if f.endswith('.npy')]
# file_len = np.random.randint(len(npy_files))
# chosen_file = npy_files[file_len]
# brain_index = np.load(os.path.join(directory, chosen_file))





import torch

# 指定张量文件路径
tensor_path = '/media/amax/DE105765105744252/endtoend/2023Challenge/mt_.pth'

# 加载张量
tensor = torch.load(tensor_path)

print("张量加载完成")




# print(tensor)

# import numpy as np
# a=np.load('/media/amax/DE105765105744251/endtoend/2023Challenge/data_code/algonauts_2023_challenge_data/subj01/voxel_indexs/V4.npy')

# import numpy as np
#
# # 生成从1到6405的数组
# numbers = np.arange(44324, 45263)  # np.arange 的结束值是开区间，所以需要设置为 6406
#
# # 保存数组到 npy 文件
# np.save('/media/amax/DE105765105744251/endtoend/2023Challenge/data_code/algonauts_2023_challenge_data/subj01/voxel_indexs/v3b.npy', numbers)
#
# print("数组已生成并保存到 numbers.npy")



# import numpy as np
#
# # 生成包含随机整数的数组
# min_value = 1
# max_value = 6405  # np.random.randint 生成的是 [min_value, max_value) 区间的数，所以上限设为 6405
# size = 6404  # 数组大小为 6404
#
# random_numbers = np.random.randint(min_value, max_value, size)
# random_numbers.sort()
# # 保存数组到 V1.npy 文件
# np.save('/media/amax/DE105765105744251/endtoend/2023Challenge/data_code/algonauts_2023_challenge_data/subj01/voxel_indexs/V1.npy', random_numbers)
#
# print("随机数已生成并保存到 V1.npy")





# # 获取目录中的所有 .npy 文件
# import numpy as np
# import os
#
# # 定义存储 .npy 文件的目录和目标文件名
# directory = '/media/amax/DE105765105744251/endtoend/sub05/'   # 替换为你的 .npy 文件所在目录
# output_file = '/media/amax/DE105765105744251/endtoend/sub05/merged_data.npy'
#
# # 生成文件名列表，从 '1.npy' 到 '13.npy'
# npy_files = [f"{i}.npy" for i in range(1, 14)]
#
# # 确保这些文件存在
# for file_name in npy_files:
#     if not os.path.isfile(os.path.join(directory, file_name)):
#         raise FileNotFoundError(f"文件 {file_name} 不存在于目录 {directory}")
#
# # 读取第一个 .npy 文件
# data_list = [np.load(os.path.join(directory, npy_files[0]))]
#
# # 依次读取其余的 .npy 文件，并合并
# for file_name in npy_files[1:]:
#     data = np.load(os.path.join(directory, file_name))
#     data_list.append(data)
#
# # 将所有数据堆叠到一起（假设你希望在第一个维度上堆叠）
# merged_data = np.concatenate(data_list, axis=1)
#
# # 保存合并后的数据到新的 .npy 文件
# np.save(os.path.join(directory, output_file), merged_data)
#
# print(f"合并后的数据已保存到 {os.path.join(directory, output_file)}")




# import os
#
# # 文件夹路径
# folder_path = '/media/amax/DE105765105744251/endtoend/2023Challenge/data_code/algonauts_2023_challenge_data/subj01/training_split/training_images111'
#
# # 遍历文件夹中的所有 jpg 文件
# for i in range(1, 1321):
#     old_name = f'{i:04d}.jpg'  # 原始文件名，如 '0001.jpg'
#     new_name = f'train_{i:04d}.jpg'  # 新文件名，如 'train_0001.jpg'
#
#     # 完整路径
#     old_file = os.path.join(folder_path, old_name)
#     new_file = os.path.join(folder_path, new_name)
#
#     # 检查文件是否存在，然后重命名
#     if os.path.exists(old_file):
#         os.rename(old_file, new_file)
#         print(f'Renamed {old_name} to {new_name}')
#     else:
#         print(f'File {old_name} does not exist')
#
# print('Renaming completed.')
# import torch
# import torch.nn as nn
# a= torch.load("/media/amax/DE105765105744251/endtoend/2023Challenge/V1_.pth")
#
# import torch
# import pickle
# import numpy as np
# model = np.load('/media/amax/DE105765105744251/endtoend/2023Challenge/data_code/algonauts_2023_challenge_data/subj01/training_split/training_fmri/V1.npy')
#
#
# # last_30_rows = model[-30:]
#
# sorted_rows = np.sort(model, axis=1)[:, ::-1]
# top_100_cor_v = sorted_rows[:, :100]
# mean_values = np.mean(top_100_cor_v , axis=0)
#
# cor = np.median(mean_values)
# print(cor)
#     # average_top_100 = np.mean(top
# a=np.load('/media/amax/DE10576510574425/endtoend/2023Challenge/data_code/algonauts_2023_challenge_data/subj01/training_split/training_fmri/fmri_data.npy')
# # 加载 pkl 文件
# with open('/media/amax/DE10576510574425/htROI/Algonauts_2021_data/raw/participants_data_v2021/full_track/sub01/WB.pkl', 'rb') as f:
#     data = pickle.load(f)
#
# fmri_data = np.mean(data["train"], axis=1)
#
# np.save('/media/amax/DE10576510574425/endtoend/2023Challenge/data_code/algonauts_2023_challenge_data/subj01/training_split/training_fmri/fmri_data.npy', fmri_data)
# # import torch
# import torch.nn as nn
#
# # 定义一个简单的神经网络模型
# class SimpleModel(nn.Module):
#     def __init__(self):
#         super(SimpleModel, self).__init__()
#         self.fc1 = nn.Linear(784, 256)
#         self.relu = nn.ReLU()
#         self.fc2 = nn.Linear(256, 10)
#
#     def forward(self, x):
#         x = x.view(x.size(0), -1)
#         x = self.fc1(x)
#         x = self.relu(x)
#         x = self.fc2(x)
#         return x
#
# # 创建模型实例
# model = SimpleModel()
#
# # 打印每层的参数数量
# for name, param in model.named_parameters():
#     if param.requires_grad:
#         print(f"Layer: {name} | Size: {param.numel()}")
#
# # 统计总参数数量
# total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
# print(f"Total Trainable Parameters: {total_params}")





# import cv2
# import os
#
# # 输入视频文件夹路径
# input_folder = '/media/amax/DE10576510574425/endtoend/2023Challenge/data_code/algonauts_2023_challenge_data/subj01/training_split/training_videos/'
#
# # 输出视频文件夹路径
# output_folder = '/media/amax/DE10576510574425/endtoend/2023Challenge/data_code/428x428_videos/'
#
# # 确保输出文件夹存在，如果不存在则创建
# os.makedirs(output_folder, exist_ok=True)
#
# # 获取输入文件夹中所有视频文件的路径
# video_files = os.listdir(input_folder)
# video_files = [f for f in video_files if f.endswith('.mp4')]
#
# # 设置输出视频的分辨率
# output_width = 428
# output_height = 428
#
# for video_file in video_files:
#     # 构建输入和输出视频的完整路径
#     input_video_path = os.path.join(input_folder, video_file)
#     output_video_path = os.path.join(output_folder, video_file)
#
#     # 打开视频文件
#     cap = cv2.VideoCapture(input_video_path)
#
#     # 获取视频的帧率和尺寸
#     fps = cap.get(cv2.CAP_PROP_FPS)
#     frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
#     frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
#
#     # 定义输出视频编解码器及其参数
#     fourcc = cv2.VideoWriter_fourcc(*'mp4v')
#     out = cv2.VideoWriter(output_video_path, fourcc, fps, (output_width, output_height))
#
#     while cap.isOpened():
#         ret, frame = cap.read()
#         if not ret:
#             break
#
#         # 缩放帧大小为 428x428
#         resized_frame = cv2.resize(frame, (output_width, output_height))
#
#         # 写入输出视频文件
#         out.write(resized_frame)
#
#         # 显示处理后的帧（可选）
#         # cv2.imshow('Resized Frame', resized_frame)
#         # if cv2.waitKey(1) & 0xFF == ord('q'):
#         #     break
#
#     # 释放资源
#     cap.release()
#     out.release()
#
# # 关闭所有打开的窗口
# # cv2.destroyAllWindows()
#
#
#
#
#
#
#
#
# # import cv2
# #
# # # 输入视频文件路径
# # input_video_path = '/media/amax/DE10576510574425/endtoend/2023Challenge/data_code/algonauts_2023_challenge_data/subj01/training_split/training_videos/0001.mp4'
# #
# # # 输出视频文件路径
# # output_video_path = '/media/amax/DE10576510574425/endtoend/2023Challenge/data_code/0001.mp4'
# #
# # # 打开视频文件
# # cap = cv2.VideoCapture(input_video_path)
# #
# # # 获取视频的帧率和尺寸
# # fps = cap.get(cv2.CAP_PROP_FPS)
# # frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
# # frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
# #
# # # 设置输出视频的分辨率
# # output_width = 428
# # output_height = 428
# #
# # # 定义输出视频编解码器及其参数
# # fourcc = cv2.VideoWriter_fourcc(*'mp4v')
# # out = cv2.VideoWriter(output_video_path, fourcc, fps, (output_width, output_height))
# #
# # while cap.isOpened():
# #     ret, frame = cap.read()
# #     if not ret:
# #         break
# #
# #     # 缩放帧大小为 428x428
# #     resized_frame = cv2.resize(frame, (output_width, output_height))
# #
# #     # 写入输出视频文件
# #     out.write(resized_frame)
# #
# #     # 显示处理后的帧（可选）
# #     cv2.imshow('Resized Frame', resized_frame)
# #     if cv2.waitKey(1) & 0xFF == ord('q'):
# #         break
# #
# # # 释放资源
# # cap.release()
# # out.release()
# # cv2.destroyAllWindows()
#
#
#
#
# # import numpy as np
# #
# # a=np.load("/media/amax/DE10576510574425/endtoend/Results/改_1/sub01/COR/V1_corVector_val.npy", allow_pickle=False)
# # ddd=a
#
#
#
#
# # import pickle
# #
# #
# # def load_pickle_file(file_path):
# #     try:
# #         with open(file_path, 'rb') as f:
# #             data = pickle.load(f)
# #         return data
# #     except FileNotFoundError:
# #         print(f"Error: File '{file_path}' not found.")
# #         return None
# #     except Exception as e:
# #         print(f"An error occurred: {e}")
# #         return None
# #
# #     # 使用函数加载.pickle文件
# #
# #
# # pickle_file_path = 'G:/zwc/2023Challenge/CLIP/anno/subj01_trn_anno.pickle'  # 替换为你的.pickle文件路径
# # loaded_data = load_pickle_file(pickle_file_path)
# #
# # if loaded_data is not None:
# #     # 在这里处理加载的数据
# #     print(loaded_data)