#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 27 09:57:34 2018

@author: amax
"""

import numpy as np
import torch
import cv2
import os
from torch.utils.data import Dataset
import matplotlib.pyplot as plt
from pathlib import Path
from PIL import Image
from torchvision import transforms

class MyDataset(torch.utils.data.Dataset):
    def __init__(self, root, datatxt, size, transform=None):  # root:数据集图片路径  datatxt:label
        fn = open(datatxt, 'r')
        data = []  #空的，用来存图片名字和类别标签
        for line in fn:
            line = line.rstrip()   #删除类别标签 blog.csdn.net/qq_41800366/article/details/88081034
            words = line.split()   #stimtrn_714.png 5 按空格分割为words[0]：stimtrn_714.pn和 words[1]：5
            data.append((words[0], int(words[1])))  ##两个数据填入  空的   date
            
        self.data = data
        self.transform = transform
        self.root = root
        self.size = size
        
    def __getitem__(self, index):
        img_name, label = self.data[index]   #读前面存入DATE 数据，  图片名字  和 标 签
        img = cv2.imread(os.path.join(self.root,img_name))   #路径合成，指向具体某张图片的路径，然后读入
        img = np.array(cv2.resize(img, (self.size,self.size))).transpose((2,0,1))
        #裁剪图片到前面制定的 SIZE，X轴用0表示，Y轴用1表示；Z轴用2来表示，然后下x,y,z  转变为  z,x,y   ???目的是什么
        #cnblogs.com/caizhou520/p/11227986.html
        img = (img-np.min(img))/(np.max(img)-np.min(img))-0.5    
        label = label-1
        return img, label   ####   这一系列操作的目的？？？？
        
    def __len__(self):
        return len(self.data)

# device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")

# transform = transforms.Compose([
#     transforms.Resize((224, 224)),  # resize the images to 224x24 pixels
#     transforms.ToTensor(),  # convert the images to a PyTorch tensor
#     transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])  # normalize the images color channels
# ])

class ImageDatasetNEW(Dataset):
    def __init__(self, imgs_paths, vs, idxs, transform):
        self.imgs_paths = np.array(imgs_paths)[idxs]
        self.voxel = vs[idxs]
        self.transform = transform

    def __len__(self):
        return len(self.imgs_paths)

    def __getitem__(self, idxs):
        # Load the image
        img_path = self.imgs_paths[idxs]
        img = Image.open(img_path).convert('RGB')
        img = np.asarray(img)
        img = np.asarray(cv2.resize(img, (224, 224))).transpose((2, 0, 1))
        # print('img_dim', img.shape)
        v = self.voxel[idxs]
        # Preprocess the image and send it to the chosen device ('cpu' or 'cuda')
        # if self.transform:
            # img = self.transform(img).to(device)
        return img, 1, v


# class GallantDataset(torch.utils.data.Dataset):   #这个 是带有  体素响应的 vs
#     def __init__(self, im_dir, datatxt, vs, size, transform=None):
#         fn = open(datatxt, 'r')
#         data = []
#         for line in fn:
#             line = line.rstrip()
#             words = line.split()
#             data.append((words[0], int(words[1])))
#
#         self.data = data
#         self.transform = transform
#         self.im_dir = im_dir
#         self.voxel = vs
#         self.size = size
#
#     def __getitem__(self, index):
#         img_name, label = self.data[index]
#         img = cv2.imread(os.path.join(self.im_dir,img_name))
#         img = np.array(cv2.resize(img, (self.size,self.size))).transpose((2,0,1))
#         img = (img-np.min(img))/(np.max(img)-np.min(img))-0.5
#
# #        ## data enhancement
# #        img = img*1.2
# #        img[img > 0.5] = 0.5
# #        img[img < -0.5] = -0.5
# #        ##
#         label = label-1
#         v = self.voxel[index]
#         img = np.expand_dims(img[0,:,:], 0)
#         return img, label, v
#
#     def __len__(self):
#         return len(self.data)


# if __name__ == '__main__':
#     root_trn = 'F:\py_work\Gabornet\stimtrn'
#     datatxt_trn = 'F:\py_work\Gabornet\stimtrn.txt'
#     root_val = 'F:\py_work\Gabornet\stimval'
#     datatxt_val = 'F:\py_work\Gabornet\stimval.txt'
#     dataset_trn = MyDataset(root_trn, datatxt_trn, 224)
#     dataset_val = MyDataset(root_val, datatxt_val, 224)
#
#     loader_trn = torch.utils.data.DataLoader(dataset_trn,
#                                              batch_size=16,
#                                              shuffle=True,
#                                              num_workers=2,
#                                              drop_last=True)
#
#     loader_val = torch.utils.data.DataLoader(dataset_val,
#                                              batch_size=16,
#                                              shuffle=False,
#                                              num_workers=2,
#                                              drop_last=False)
#
#     area = 'LO'
#     data_dir = 'F:\py_work\Gabornet\Gallant_data'
#     vs_trn = np.load(os.path.join(data_dir, '%strn_s1.npy'%(area)))
#     vs_val = np.load(os.path.join(data_dir, '%sval_s1.npy'%(area)))
#     vs_trn = np.asarray(vs_trn, dtype=np.float64)
#     vs_val = np.asarray(vs_val, dtype=np.float64)
#
#     gallantdataset_trn = ImageDatasetNEW(root_trn, vs_trn, idxs_train, 224)
#     gallantdataset_val = ImageDatasetNEW(root_val, vs_val, idxs_val,224)
#
#     gallantloader_trn = torch.utils.data.DataLoader(gallantdataset_trn,
#                                                      batch_size=16,
#                                                      shuffle=False,
#                                                      num_workers=2,
#                                                      drop_last=False)
#     gallantloader_val = torch.utils.data.DataLoader(gallantdataset_val,
#                                                      batch_size=16,
#                                                      shuffle=False,
#                                                      num_workers=2,
#                                                      drop_last=False)
#
#     for i, data in enumerate(gallantloader_val):
#         im, label, voxel = data
#
# #        plt.imshow(im[0].numpy().transpose((1,2,0))+0.5)
#         im = im[0].numpy()+0.5
# #        im = im.transpose((1,2,0))
#         print(im.shape)
#         plt.imshow(im[0], cmap='gray')
#         plt.show()
#         print(label.shape)
#         print(voxel.shape)



    
