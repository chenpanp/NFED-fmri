import os
import numpy as np
import pandas as pd
from openpyxl import Workbook




folder_path = r"I:\COR"

wb = Workbook()
ws = wb.active

for filename in os.listdir(folder_path):
    if filename.endswith(".npy"):
        filepath = os.path.join(folder_path, filename)
        data = np.load(filepath)
        data1 = float(data)
        filename1 = filename[0 : -18]
        print("File name:", filename1)
        print(data1)
        ws.append([filename1, data1])

wb.save('sub01_left_改2_1_fig&text.xlsx')
