###
# This file will:
# 1. Generate and save Alexnet features in a given folder
# 2. preprocess Alexnet features using PCA and save them in another folder
###
import glob
import torch
import InternVideo
import numpy as np
import urllib
import torch
import cv2
import argparse
import time
import random
from tqdm import tqdm
from torchvision import transforms as trn
import os
from PIL import Image
from sklearn.preprocessing import StandardScaler
from torch.autograd import Variable as V
from sklearn.decomposition import PCA, IncrementalPCA
from decord import VideoReader
from decord import cpu

seed = 42
# Torch RNG
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
torch.cuda.manual_seed_all(seed)
# Python RNG
np.random.seed(seed)
random.seed(seed)

def get_activations_and_save(model, video_dir, text_folder, activations_dir):
    """This function generates Alexnet features and save them in a specified directory.
    Parameters
    ----------
    model :
        pytorch model : alexnet.
    video_list : list
        the list contains path to all videos.
    activations_dir : str
        save path for extracted features.
    """

    video_files = os.listdir(video_dir)
    video_files.sort()
    for video_file_name in tqdm(video_files):
        vide_file_path = os.path.join(video_dir, video_file_name)
        video = InternVideo.load_video(vide_file_path).cuda()

        txt_file_name = int(video_file_name.split("_")[0])
        # 构建文本文件路径
        text_file = os.path.join(text_folder, str(txt_file_name) + ".txt")
        with open(text_file, 'r') as f:
            text_cand = f.read()

        text = InternVideo.tokenize(
            text_cand
        ).cuda()

        with torch.no_grad():
            video_features = model.encode_video(video.unsqueeze(0))
            text_features = model.encode_text(text)
            fusion_features = video_features + text_features
            # tmp = video_features + text_features
            # tmp = conv(tmp)
            text_features = torch.nn.functional.normalize(text_features, dim=1).detach().cpu().numpy()
            video_features = torch.nn.functional.normalize(video_features, dim=1).detach().cpu().numpy()
            fusion_features = torch.nn.functional.normalize(fusion_features, dim=1).detach().cpu().numpy()

        video_file_name_tmp = video_file_name.split(".")[0]
        #
        video_save_path = os.path.join(activations_dir, video_file_name_tmp + "_video.npy")
        txt_save_path = os.path.join(activations_dir, video_file_name_tmp + "_txt.npy")
        fusion_save_path = os.path.join(activations_dir, video_file_name_tmp + "_fusion.npy")

        np.save(video_save_path, video_features)
        np.save(txt_save_path, text_features)
        np.save(fusion_save_path, fusion_features)


def do_PCA_and_save(activations_dir, save_dir, index):
    """This function preprocesses Neural Network features using PCA and save the results
    in  a specified directory
.

    Parameters
    ----------
    activations_dir : str
        save path for extracted features.
    save_dir : str
        save path for extracted PCA features.

    """

    n_components = 100
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)

    activations_file_list = glob.glob(activations_dir + '/*' + '{}.npy'.format(index))
    activations_file_list.sort()
    feature_dim = np.load(activations_file_list[0])
    x = np.zeros((len(activations_file_list), feature_dim.shape[1]))
    for i, activation_file in enumerate(activations_file_list):
        temp = np.load(activation_file)
        x[i, :] = temp
    x_train = x[:1000, :]
    # x_test = x[1000:, :]

    start_time = time.time()
    # x_test = StandardScaler().fit_transform(x_test)
    x_train = StandardScaler().fit_transform(x_train)

    ipca = PCA(n_components=n_components, random_state=seed)
    ipca.fit(x_train)

    x_train = ipca.transform(x_train)
    # x_test = ipca.transform(x_test)
    train_save_path = os.path.join(save_dir, "train{}".format(index))
    # test_save_path = os.path.join(save_dir, "test")
    np.save(train_save_path, x_train)
    # np.save(test_save_path, x_test)


def main():
    parser = argparse.ArgumentParser(description='Feature Extraction from Alexnet and preprocessing using PCA')
    parser.add_argument('-vdir', '--video_data_dir', help='video data directory',
                        default='E:\\videoencode\\participants_data\\AlgonautsVideos268_All_30fpsmax\\', type=str)
    parser.add_argument('-sdir', '--save_dir', help='saves processed features', default=r'E:\Algonauts2021_devkit-main\feature\internvideo_feature',
                        type=str)
    args = vars(parser.parse_args())

    save_dir = args['save_dir']
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)

    video_dir = args['video_data_dir']
    video_list = glob.glob(video_dir + '/*.mp4')
    # video_list.sort()
    print('Total Number of Videos: ', len(video_list))
    # 文本文件夹路径
    text_folder = "D:/dataZL/Multi-Modalities-Pretraining/clip/"
    # load Alexnet
    # Download pretrained Alexnet from:
    # https://download.pytorch.org/models/alexnet-owt-4df8aa71.pth
    # and save in the current directory
    # checkpoint_path = "./alexnet.pth"
    # if not os.path.exists(checkpoint_path):
    #     url = "https://download.pytorch.org/models/alexnet-owt-4df8aa71.pth"
    #     urllib.request.urlretrieve(url, "./alexnet.pth")
    # model = load_alexnet(checkpoint_path)


    model = InternVideo.load_model("models/InternVideo-MM-B-16.ckpt").cuda()
    # get and save activations
    activations_dir = os.path.join(save_dir)
    if not os.path.exists(activations_dir):
        os.makedirs(activations_dir)
    print("-------------Saving activations ----------------------------")
    get_activations_and_save(model, video_dir, text_folder, activations_dir)

    # preprocessing using PCA and save
    pca_dir = os.path.join(save_dir, 'pca_100')
    print("-------------performing  PCA----------------------------")
    index = "_video" # _txt or _fusion
    do_PCA_and_save(activations_dir, pca_dir,index)
    index = "_txt"
    do_PCA_and_save(activations_dir, pca_dir, index)
    index = "_fusion"
    do_PCA_and_save(activations_dir, pca_dir, index)


if __name__ == "__main__":
    main()
